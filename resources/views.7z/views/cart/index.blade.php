@extends('layouts.app')

@section('title', 'Keranjang Belanja - MINIMARKET-4')

@section('content')
<div class="cart-container">
    <div class="cart-header">
        <h1>🛒 Keranjang Belanja</h1>
        <nav class="breadcrumb">
            <a href="{{ route('home') }}">Home</a>
            <span>/</span>
            <span>Keranjang Belanja</span>
        </nav>
    </div>

    <div class="cart-content">
        <div class="cart-items-section">
            <div class="section-header">
                <h2>Produk di Keranjang</h2>
                @if($cartItems->count() > 0)
                    <button class="clear-cart-btn" id="clearCart">
                        <i class="fas fa-trash"></i> Kosongkan Keranjang
                    </button>
                @endif
            </div>

            @if($cartItems->count() > 0)
                <div class="cart-items">
                    @foreach($cartItems as $item)
                    <div class="cart-item" data-id="{{ $item->id }}">
                        <div class="item-image">
                            <img src="{{ $item->image_url }}" alt="{{ $item->product_name }}" 
                                 onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&h=150&fit=crop'">
                        </div>
                        <div class="item-details">
                            <h3 class="item-name">{{ $item->product_name }}</h3>
                            <p class="item-price">Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                            <div class="item-actions">
                                <div class="quantity-controls">
                                    <button class="quantity-btn minus" data-id="{{ $item->id }}">-</button>
                                    <span class="quantity">{{ $item->quantity }}</span>
                                    <button class="quantity-btn plus" data-id="{{ $item->id }}">+</button>
                                </div>
                                <button class="remove-btn" data-id="{{ $item->id }}">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </div>
                        </div>
                        <div class="item-subtotal">
                            Rp <span class="subtotal-amount">{{ number_format($item->price * $item->quantity, 0, ',', '.') }}</span>
                        </div>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="empty-cart">
                    <div class="empty-icon">🛒</div>
                    <h3>Keranjang Belanja Kosong</h3>
                    <p>Belum ada produk di keranjang belanja Anda</p>
                    <a href="{{ route('home') }}" class="continue-shopping-btn">
                        <i class="fas fa-shopping-bag"></i> Lanjutkan Belanja
                    </a>
                </div>
            @endif
        </div>

        @if($cartItems->count() > 0)
        <div class="cart-summary">
            <div class="summary-card">
                <h3>Ringkasan Belanja</h3>
                
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span class="summary-total">Rp {{ number_format($total, 0, ',', '.') }}</span>
                </div>
                
                <div class="summary-row">
                    <span>Pengiriman:</span>
                    <span class="shipping-cost">
                        @if($total >= 50000)
                            <span style="color: #4CAF50;">Gratis</span>
                        @else
                            Rp 10.000
                        @endif
                    </span>
                </div>
                
                <div class="summary-divider"></div>
                
                <div class="summary-row total">
                    <span>Total:</span>
                    <span class="final-total">
                        Rp {{ number_format($total >= 50000 ? $total : $total + 10000, 0, ',', '.') }}
                    </span>
                </div>

                <button class="checkout-btn">
                    <i class="fas fa-credit-card"></i> Lanjut ke Pembayaran
                </button>

                <div class="shipping-info">
                    <div class="info-item">
                        <i class="fas fa-shipping-fast"></i>
                        <span>Gratis ongkir untuk order di atas Rp 50.000</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-credit-card"></i>
                        <span>Pembayaran aman & fleksibel</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-headset"></i>
                        <span>Support 24/7</span>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

<style>
.cart-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.cart-header {
    text-align: center;
    margin-bottom: 40px;
}

.cart-header h1 {
    font-family: 'Poppins', sans-serif;
    font-size: 2.5rem;
    color: var(--dark-text);
    margin-bottom: 10px;
}

.breadcrumb {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    color: var(--medium-text);
}

.breadcrumb a {
    color: var(--purple-pastel);
    text-decoration: none;
}

.breadcrumb a:hover {
    color: var(--dark-text);
}

.cart-content {
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 40px;
}

.cart-items-section {
    background: var(--white);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 8px 20px var(--shadow);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--pink-pastel);
}

.section-header h2 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.8rem;
    color: var(--dark-text);
}

.clear-cart-btn {
    background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    cursor: pointer;
    font-family: 'Quicksand', sans-serif;
    font-weight: 600;
    transition: all 0.3s ease;
}

.clear-cart-btn:hover {
    background: linear-gradient(135deg, #ff5252, #ff7979);
    transform: translateY(-2px);
}

.cart-items {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.cart-item {
    display: grid;
    grid-template-columns: 100px 1fr auto;
    gap: 20px;
    padding: 20px;
    background: var(--white);
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    border: 2px solid transparent;
    transition: all 0.3s ease;
}

.cart-item:hover {
    border-color: var(--purple-pastel);
    transform: translateY(-2px);
}

.item-image {
    width: 100px;
    height: 100px;
    border-radius: 10px;
    overflow: hidden;
}

.item-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.item-details {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.item-name {
    font-family: 'Poppins', sans-serif;
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--dark-text);
    margin-bottom: 5px;
}

.item-price {
    color: #ff6b6b;
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 15px;
}

.item-actions {
    display: flex;
    gap: 15px;
    align-items: center;
}

.quantity-controls {
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--pink-pastel);
    border-radius: 25px;
    padding: 5px 15px;
}

.quantity-btn {
    background: none;
    border: none;
    font-size: 1.2rem;
    cursor: pointer;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.quantity-btn:hover {
    background: var(--purple-pastel);
}

.quantity {
    font-weight: 600;
    min-width: 30px;
    text-align: center;
}

.remove-btn {
    background: none;
    border: 2px solid var(--pink-pastel);
    color: var(--dark-text);
    padding: 8px 15px;
    border-radius: 8px;
    cursor: pointer;
    font-family: 'Quicksand', sans-serif;
    font-weight: 600;
    transition: all 0.3s ease;
}

.remove-btn:hover {
    background: #ff6b6b;
    color: white;
    border-color: #ff6b6b;
}

.item-subtotal {
    font-family: 'Poppins', sans-serif;
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--dark-text);
    display: flex;
    align-items: center;
}

.empty-cart {
    text-align: center;
    padding: 60px 20px;
}

.empty-icon {
    font-size: 4rem;
    margin-bottom: 20px;
}

.empty-cart h3 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.8rem;
    color: var(--dark-text);
    margin-bottom: 10px;
}

.empty-cart p {
    color: var(--medium-text);
    margin-bottom: 30px;
}

.continue-shopping-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, var(--purple-pastel), var(--blue-pastel));
    color: var(--dark-text);
    text-decoration: none;
    padding: 15px 30px;
    border-radius: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.continue-shopping-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}

.cart-summary {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.summary-card {
    background: var(--white);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 8px 20px var(--shadow);
}

.summary-card h3 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.5rem;
    color: var(--dark-text);
    margin-bottom: 25px;
    text-align: center;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding: 10px 0;
}

.summary-row.total {
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--dark-text);
    border-top: 2px solid var(--pink-pastel);
    margin-top: 10px;
    padding-top: 15px;
}

.summary-divider {
    height: 1px;
    background: var(--pink-pastel);
    margin: 20px 0;
}

.checkout-btn {
    width: 100%;
    background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
    color: white;
    border: none;
    padding: 18px;
    border-radius: 12px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all 0.3s ease;
    margin: 25px 0;
}

.checkout-btn:hover {
    background: linear-gradient(135deg, #ff5252, #ff7979);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(255, 107, 107, 0.3);
}

.shipping-info {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 12px;
    color: var(--medium-text);
    font-size: 0.9rem;
}

.info-item i {
    color: var(--purple-pastel);
    width: 20px;
}

@media (max-width: 968px) {
    .cart-content {
        grid-template-columns: 1fr;
    }
    
    .cart-summary {
        position: static;
    }
}

@media (max-width: 768px) {
    .cart-item {
        grid-template-columns: 80px 1fr;
        gap: 15px;
    }
    
    .item-subtotal {
        grid-column: 1 / -1;
        justify-content: flex-end;
        margin-top: 10px;
    }
    
    .item-actions {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Function to update cart totals
    function updateCartTotals(data) {
        document.querySelectorAll('.cart-total').forEach(el => {
            el.textContent = 'Rp ' + data.total.toLocaleString('id-ID');
        });
        
        document.querySelectorAll('.cart-count').forEach(el => {
            el.textContent = data.cart_count;
        });
    }
    
    // Quantity increase
    document.querySelectorAll('.quantity-increase').forEach(button => {
        button.addEventListener('click', function() {
            const cartItemId = this.closest('.cart-item').dataset.id;
            const quantityInput = this.parentElement.querySelector('.quantity-input');
            let quantity = parseInt(quantityInput.value) + 1;
            quantityInput.value = quantity;
            updateCartItem(cartItemId, quantity);
        });
    });
    
    // Quantity decrease
    document.querySelectorAll('.quantity-decrease').forEach(button => {
        button.addEventListener('click', function() {
            const cartItemId = this.closest('.cart-item').dataset.id;
            const quantityInput = this.parentElement.querySelector('.quantity-input');
            let quantity = parseInt(quantityInput.value) - 1;
            
            if (quantity < 1) quantity = 1;
            quantityInput.value = quantity;
            updateCartItem(cartItemId, quantity);
        });
    });
    
    // Quantity input change
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            const cartItemId = this.closest('.cart-item').dataset.id;
            let quantity = parseInt(this.value);
            
            if (quantity < 1) quantity = 1;
            this.value = quantity;
            updateCartItem(cartItemId, quantity);
        });
    });
    
    // Update cart item
    function updateCartItem(cartItemId, quantity) {
        fetch(`/cart/update/${cartItemId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update subtotal for this item
                const subtotalElement = document.querySelector(`[data-id="${cartItemId}"] .subtotal-amount`);
                subtotalElement.textContent = 'Rp ' + data.subtotal.toLocaleString('id-ID');
                
                // Update totals
                updateCartTotals(data);
                
                showNotification('Keranjang berhasil diperbarui!');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Gagal memperbarui keranjang!', 'error');
        });
    }
    
    // Remove cart item
    document.querySelectorAll('.remove-item-btn').forEach(button => {
        button.addEventListener('click', function() {
            const cartItemId = this.closest('.cart-item').dataset.id;
            removeCartItem(cartItemId);
        });
    });
    
    function removeCartItem(cartItemId) {
        if (confirm('Apakah Anda yakin ingin menghapus produk ini?')) {
            fetch(`/cart/remove/${cartItemId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove item from DOM
                    document.querySelector(`[data-id="${cartItemId}"]`).remove();
                    
                    // Update totals
                    updateCartTotals(data);
                    
                    showNotification('Produk berhasil dihapus dari keranjang!');
                    
                    // If cart is empty, show empty message
                    if (data.cart_count === 0) {
                        document.querySelector('.cart-items').innerHTML = `
                            <div class="empty-cart">
                                <h3>Keranjang Anda kosong</h3>
                                <p>Silakan tambahkan produk ke keranjang Anda</p>
                                <a href="{{ route('home') }}" class="btn btn-primary">Lanjutkan Belanja</a>
                            </div>
                        `;
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Gagal menghapus produk dari keranjang!', 'error');
            });
        }
    }
    
    // Clear cart
    document.querySelectorAll('.clear-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Apakah Anda yakin ingin mengosongkan keranjang?')) {
                fetch('/cart/clear', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Clear all items from DOM
                        document.querySelectorAll('.cart-item').forEach(item => item.remove());
                        
                        // Update totals
                        updateCartTotals(data);
                        
                        // Show empty message
                        document.querySelector('.cart-items').innerHTML = `
                            <div class="empty-cart">
                                <h3>Keranjang Anda kosong</h3>
                                <p>Silakan tambahkan produk ke keranjang Anda</p>
                                <a href="{{ route('home') }}" class="btn btn-primary">Lanjutkan Belanja</a>
                            </div>
                        `;
                        
                        showNotification('Keranjang berhasil dikosongkan!');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Gagal mengosongkan keranjang!', 'error');
                });
            }
        });
    });
    
    // Notification function
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `cart-notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${type === 'success' ? '✓' : '⚠'}</span>
                <span class="notification-text">${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
});
</script>
@endsection