@extends('layouts.app')

@section('title', 'Dashboard Grocery Shopping')

@section('content')
<div class="dashboard-container">
    <!-- Header -->
    <header class="dashboard-header">
        <h1>MINIMARKET-4</h1>
    </header>

    <!-- Favorite Categories -->
    <section class="categories-section">
        <div class="section-header">
            <h3>Jelajahi Kategori Favorit Anda</h3>
        </div>
        <div class="categories-grid">
            @foreach(array_unique($favoriteCategories) as $category)
            <div class="category-card">
                <div class="category-icon">
                    @switch($category)
                        @case('Perfume') 🌸 @break
                        @case('Makanan Beku') ❄️ @break
                        @case('Daging & Seafood') 🍖 @break
                        @case('Buah & Sayur') 🍎 @break
                        @case('Bumbu Dapur') 🌶️ @break
                        @case('Perlengkapan Rumah') 🏠 @break
                        @default 🛍️
                    @endswitch
                </div>
                <span>{{ $category }}</span>
            </div>
            @endforeach
        </div>
    </section>

    <!-- Flash Sale Products -->
    <section class="flash-sale-section">
        <div class="section-header">
            <h3>🔥 Flash Sale Products</h3>
            <p>Limited time offers! Hurry before they're gone!</p>
            <div class="sale-timer">
                <div class="timer-item">
                    <span class="timer-number" id="hours">02</span>
                    <span class="timer-label">Hours</span>
                </div>
                <div class="timer-item">
                    <span class="timer-number" id="minutes">15</span>
                    <span class="timer-label">Minutes</span>
                </div>
                <div class="timer-item">
                    <span class="timer-number" id="seconds">30</span>
                    <span class="timer-label">Seconds</span>
                </div>
            </div>
        </div>
        <div class="flash-sale-grid">
            @foreach($flashSaleProducts as $product)
            <div class="flash-sale-card">
                <div class="sale-badge">-{{ $product['discount_percent'] }}%</div>
                <div class="product-image">
                    <img src="{{ $product['image_url'] }}" alt="{{ $product['name'] }}" onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=300&fit=crop'">
                    <div class="time-left">⏰ {{ $product['time_left'] }}</div>
                </div>
                <div class="product-info">
                    <h4>{{ $product['name'] }}</h4>
                    <p>{{ $product['description'] }}</p>
                    <div class="price-section">
                        <span class="original-price">{{ number_format($product['original_price'], 2) }}</span>
                        <span class="discount-price">{{ number_format($product['discount_price'], 2) }}</span>
                    </div>
                    <div class="progress-section">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ ($product['sold'] / $product['total']) * 100 }}%"></div>
                        </div>
                        <div class="sold-text">Sold: {{ $product['sold'] }}/{{ $product['total'] }}</div>
                    </div>
                    <button class="buy-now-btn">Buy Now</button>
                </div>
            </div>
            @endforeach
        </div>
    </section>

    <!-- Popular Items -->
    <section class="popular-section">
        <div class="section-header">
            <h3>Popular</h3>
            <p>Produk paling dicari oleh pelanggan kami</p>
        </div>
        <div class="popular-grid">
            @foreach($popularItems as $index => $item)
            <div class="popular-card">
                <div class="popular-image">
                    <img src="{{ $item['image_url'] ?? 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=300&fit=crop' }}" alt="{{ $item['name'] ?? 'Product' }}" 
                         onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=300&fit=crop'">
                    <div class="rating-badge">
                        ⭐ {{ $item['rating'] ?? '0.0' }} <span class="review-count">({{ $item['reviews'] ?? '0' }})</span>
                    </div>
                </div>
                <div class="product-content">
                    <h4>{{ $item['name'] ?? 'Product Name' }}</h4>
                    <p>{{ $item['description'] ?? 'Product description' }}</p>
                    <div class="price-section">
                        <span class="price">Rp {{ number_format($item['price'] ?? 0, 0, ',', '.') }}</span>
                        <button class="add-to-cart-btn" data-product-id="{{ $item['id'] ?? $index }}">
                            <span class="cart-icon">🛒</span>
                            Tambah
                        </button>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </section>

    <!-- Specials Section -->
    <section class="specials-section">
        <div class="section-header">
            <h3>Temukan Spesial dan Penawaran Menarik!</h3>
            <p>Diskon spesial dan penawaran terbatas hanya untuk Anda</p>
        </div>
        <div class="specials-grid">
            @foreach($specials as $special)
            <div class="special-card">
                <div class="special-badge">{{ $special['badge'] }}</div>
                <div class="special-image">
                    <img src="{{ $special['image_url'] }}" alt="{{ $special['name'] }}" 
                         onerror="this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=300&fit=crop'">
                    <div class="category-tag">{{ $special['category'] }}</div>
                </div>
                <div class="special-content">
                    <h4>{{ $special['name'] }}</h4>
                    <p>{{ $special['description'] }}</p>
                    <div class="rating-info">
                        <span class="rating">⭐ {{ $special['rating'] }}</span>
                        <span class="sold-count">Terjual: {{ $special['sold'] }}</span>
                    </div>
                    <div class="price-section">
                        <div class="price-details">
                            <span class="old-price">Rp {{ number_format($special['old_price'], 0, ',', '.') }}</span>
                            <span class="new-price">Rp {{ number_format($special['new_price'], 0, ',', '.') }}</span>
                        </div>
                        <button class="buy-now-btn" data-product="{{ $special['name'] }}">
                            <span class="cart-icon">🛒</span>
                            Beli Sekarang
                        </button>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </section>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart functionality untuk semua tombol "Tambah"
    document.querySelectorAll('.add-to-cart-btn, .buy-now-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            if (productId) {
                addToCart(productId, 1);
            } else {
                showNotification('Product ID tidak ditemukan!', 'error');
            }
        });
    });
    
    function addToCart(productId, quantity) {
        console.log('Menambahkan produk:', productId, quantity);
        
        fetch('/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: quantity
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Update cart count
                document.querySelectorAll('.cart-count').forEach(el => {
                    el.textContent = data.cart_count;
                });
                
                // Show success message
                showNotification('Produk berhasil ditambahkan ke keranjang!');
            } else {
                showNotification(data.message || 'Gagal menambahkan produk!', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Gagal menambahkan produk ke keranjang! Periksa koneksi internet.', 'error');
        });
    }
    
    function showNotification(message, type = 'success') {
        // Hapus notifikasi lama jika ada
        const oldNotification = document.querySelector('.cart-notification');
        if (oldNotification) {
            oldNotification.remove();
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `cart-notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : '#f44336'};
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        
        notification.innerHTML = `
            <div class="notification-content" style="display: flex; align-items: center; gap: 10px;">
                <span class="notification-icon" style="font-size: 18px;">${type === 'success' ? '✓' : '⚠'}</span>
                <span class="notification-text">${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
});
</script>
@endsection