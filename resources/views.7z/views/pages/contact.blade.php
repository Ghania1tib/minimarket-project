<h1>Contact Us</h1>
<p>Hubungi kami di email: supermarket@example.com</p>
<a href="{{ url('/') }}">Kembali ke Home</a>
