<h1>Syarat dan Ketentuan</h1>
<p>Halaman ini berisi syarat dan ketentuan penggunaan aplikasi.</p>
<a href="{{ url('/') }}">Kembali ke Home</a>
