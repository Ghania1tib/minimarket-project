<h1>About Us</h1>
<p>Ini adalah halaman About Us Supermarket Project.</p>
<a href="{{ url('/') }}">Kembali ke Home</a>
