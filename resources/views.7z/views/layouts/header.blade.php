<header class="main-header">
    <div class="header-container">
        <!-- Logo -->
        <div class="logo-section">
            <a href="{{ route('home') }}" class="logo">
                <div class="logo-icon">🛒</div>
                <div class="logo-text">
                    <span class="logo-main">MINIMARKET-4</span>
                    <span class="logo-sub">Belanja Praktis</span>
                </div>
            </a>
        </div>

        <!-- Search Bar -->
        <div class="search-section">
            <form class="search-form" action="{{ route('search') }}" method="GET">
                <div class="search-input-group">
                    <input type="text" class="search-input" placeholder="Cari produk... (contoh: Apel, Beras, Susu)"
                        name="q" value="{{ request('q') }}">
                    <button type="submit" class="search-button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
                <div class="search-suggestions">
                    <span class="suggestion-title">Pencarian populer:</span>
                    <a href="#" class="suggestion-tag">Apel</a>
                    <a href="#" class="suggestion-tag">Beras</a>
                    <a href="#" class="suggestion-tag">Susu</a>
                    <a href="#" class="suggestion-tag">Minyak</a>
                </div>
            </form>
        </div>

        <!-- Navigation Icons -->
        <div class="nav-section">
            <!-- Cart Icon -->
            <div class="nav-item">
                <a href="{{ route('cart.index') }}" class="nav-link"> <!-- UBAH LINK INI -->
                    <div class="nav-icon">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count">{{ $cartCount ?? 0 }}</span>
                    </div>
                    <span class="nav-label">Keranjang</span>
                </a>
            </div>

            <!-- Account Icon -->
            <div class="nav-item">
                <a href="#" class="nav-link">
                    <div class="nav-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <span class="nav-label">Akun</span>
                </a>
            </div>

            <!-- About Icon -->
            <div class="nav-item">
                <a href="#" class="nav-link">
                    <div class="nav-icon">
                        <i class="fas fa-info-circle"></i>
                    </div>
                    <span class="nav-label">Tentang</span>
                </a>
            </div>
        </div>

        <!-- Account Icon -->
        <div class="nav-item">
            <a href="#" class="nav-link">
                <div class="nav-icon">
                    <i class="fas fa-user"></i>
                </div>
                <span class="nav-label">Akun</span>
            </a>
        </div>

        <!-- About Icon -->
        <div class="nav-item">
            <a href="#" class="nav-link">
                <div class="nav-icon">
                    <i class="fas fa-info-circle"></i>
                </div>
                <span class="nav-label">Tentang</span>
            </a>
        </div>
    </div>
    </div>
</header>