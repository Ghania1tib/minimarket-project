<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MINIMARKET-4- Belanja online Praktis</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* RESET GARANG - PASTI WORK */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            min-height: 100vh; 
            padding-top: 80px; /* RUANG UNTUK HEADER */
        }
        
        /* HEADER - PASTI DI ATAS */
        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 80px;
            background: white;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        /* CONTENT - PASTI DI BAWAH */
        .main-content {
            position: relative;
            z-index: 1;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <header class="main-header">
        @include('layouts.header')
    </header>
    
    <main class="main-content">
        @yield('content')
    </main>
</body>
</html>