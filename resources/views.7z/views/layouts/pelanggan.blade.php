{{-- Lokasi: resources/views/layouts/pelanggan.blade.php --}}
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minimarket</title>
    
    {{-- CSS utama Anda --}}
    <link href="{{ asset('css/app.css') }}" rel="stylesheet"> 
    
    {{-- Ini adalah "slot" untuk CSS khusus halaman --}}
    @stack('style')
</head>
<body>
    
    {{-- Di sini bisa header/navbar Anda --}}
    
    <main>
        {{-- Ini adalah "slot" untuk konten halaman --}}
        @yield('content')
    </main>

    {{-- Di sini bisa footer Anda --}}

</body>
</html>