<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

{{-- Asumsi Anda menggunakan layout. Ganti 'layouts.admin' jika perlu --}}
@extends('layouts.admin') 

@section('content')
<div class="container" style="max-width: 600px; margin-top: 50px;">
    <h2>Tambah Kategori</h2>

    {{-- Menampilkan error validasi jika ada --}}
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Oops!</strong> Ada masalah dengan input Anda.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('kategori.store') }}" method="POST">
        @csrf 

        <div style="margin-bottom: 15px;">
            <label for="nama_kategori" style="display: block; margin-bottom: 5px;">Nama Kategori</label>
            <input type="text" id="nama_kategori" name="nama_kategori" style="width: 100%; padding: 8px;" 
                   value="{{ old('nama_kategori') }}" required>
        </div>

        <div style="margin-bottom: 15px;">
            <label for="link_gambar" style="display: block; margin-bottom: 5px;">Link Gambar</label>
            <input type="text" id="link_gambar" name="link_gambar" style="width: 100%; padding: 8px;" 
                   value="{{ old('link_gambar') }}" placeholder="https://example.com/icon.png">
        </div>

        <div>
            <button type="submit" style="padding: 10px 15px; background-color: #007bff; color: white; border: none; cursor: pointer;">
                Simpan
            </button>
            <a href="{{ route('kategori.index') }}" style="padding: 10px 15px; background-color: #6c757d; color: white; text-decoration: none;">
                Kembali
            </a>
        </div>
    </form>
    @endsection

</div>

</body>
</html>
