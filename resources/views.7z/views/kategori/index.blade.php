@extends('layouts.admin')

@section('content')

    <div class="container">
        
        <div class="header-section">
            <h2>Daftar Kategori Produk</h2>
            <a href="{{ route('kategori.create') }}" class="btn-tambah">
                + Tambah Kategori
            </a>
        </div>

        @if (session('success'))
            <div class="alert-success">
                {{ session('success') }}
            </div>
        @endif

        <table class="kategori-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Ikon</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($categories as $index => $kategori)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td style="text-align: center;">
                        @if($kategori->icon_url)
                            <img src="{{ $kategori->icon_url }}" alt="{{ $kategori->nama_kategori }}">
                        @else
                            (No Image)
                        @endif
                    </td>
                    <td>{{ $kategori->nama_kategori }}</td>
                    <td>
                        <a href="#" class="edit-link">Edit</a> 
                        <a href="#" class="delete-link">Hapus</a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="4" class="empty-message">
                        Belum ada data kategori.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
@endsection