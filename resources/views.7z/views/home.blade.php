@extends('layouts.pelanggan')

@push('style')
<style>
    
    .kategori-section {
        max-width: 900px;
        margin: 40px auto;
        padding: 0 15px;
    }

    .kategori-section h2 {
        font-size: 26px;
        color: #0d6efd; /* Biru cerah */
        text-align: center;
        margin-bottom: 25px;
    }

    .kategori-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
    }

    .kategori-card {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 15px;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        background-color: #ffffff;
        text-decoration: none;
        color: #333;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.07);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .kategori-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .kategori-card img {
        width: 60px;
        height: 60px;
        margin-bottom: 15px;
        object-fit: contain;
    }

    .kategori-card span {
        font-weight: bold;
        font-size: 15px;
        text-align: center;
    }

    /* Responsive untuk HP (2 kolom) */
    @media (max-width: 768px) {
        .kategori-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }
</style>
@endpush

@section('content')

<div class="kategori-section">
        <h2>Jelajahi Kategori Favorit Anda</h2>
        <div class="kategori-container">
            
            {{-- Ganti 'kategori.show' menjadi 'category.show' --}}
            <a href="{{ route('category.show', 'parfum') }}" class="kategori-card">
                <img src="path/to/icon-perfume.png" alt="Perfume">
                <span>Perfume</span>
            </a>

            <a href="{{ route('category.show', 'bodycare') }}" class="kategori-card">
                <img src="path/to/icon-bodycare.png" alt="Bodycare">
                <span>Bodycare</span>
            </a>

            <a href="{{ route('category.show', 'Buah & Sayur') }}" class="kategori-card">
                <img src="path/to/icon-buah.png" alt="Buah & Sayur">
                <span>Buah & Sayur</span>
            </a>

            <a href="{{ route('category.show', 'Perlengkapan Rumah') }}" class="kategori-card">
                <img src="path/to/icon-rumah.png" alt="Perlengkapan Rumah">
                <span>Perlengkapan Rumah</span>
            </a>

            <a href="{{ route('category.show', 'Makanan Beku') }}" class="kategori-card">
                <img src="path/to/icon-beku.png" alt="Makanan Beku">
                <span>Makanan Beku</span>
            </a>

            <a href="{{ route('category.show', 'Daging & Seafood') }}" class="kategori-card">
                <img src="path/to/icon-daging.png" alt="Daging & Seafood">
                <span>Daging & Seafood</span>
            </a>

            <a href="{{ route('category.show', 'Bumbu Dapur') }}" class="kategori-fluid">
                <img src="path/to/icon-bumbu.png" alt="Bumbu Dapur">
                <span>Bumbu Dapur</span>
            </a>

            {{-- Ganti 'produk.index' menjadi 'products.all' --}}
            <a href="{{ route('products.all') }}" class="kategori-card">
                <img src="path/to/icon-lainnya.png" alt="Kategori Lain">
                <span>Kategori Lain</span>
            </a>

        </div>
    </div>
    
    {{-- Di sini Anda bisa meletakkan kode untuk produk unggulan ($product) --}}

@endsection